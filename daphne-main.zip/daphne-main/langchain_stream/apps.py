from django.apps import AppConfig


class LangchainStreamConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'langchain_stream'
